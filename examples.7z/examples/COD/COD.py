from __future__ import print_function
import sys
sys.path.append('../../')
import XaNSoNS
import os
import urllib
import numpy as np
class ProcessCOD:
    """Simulates x-ray or neutron powder diffraction pattern for the nanocrystallite of \
    a given structure from the Crystallography Open Database (COD), \
    http://www.crystallography.net/cod/"""
    def __init__(self,ID,size=np.array([10,10,10]),source='xray',GPU=True,CUDA=False):
        """ ID : integer
                COD structure ID
            size : nd.array
                Size of the crystallite in unit cells
            source : string
                Type of the diffraction pattern (xray or neutron)
            GPU : boolean
                Use GPU if True
            CUDA : boolean
                Use CUDA version if True"""
        self.ID=ID
        self.size=size
        self.strsize='x'.join(['%d'%s for s in self.size])
        self.source=source
        if GPU:
            if CUDA:
                self.version='CUDA'
            else:
                self.version='OpenCL'
        else:
            self.version='OMP'
    def set(self):
        """Sets up the simulation:
            1) downloads the CIF file,
            2) creates the XML configuration,
            3) imports from CIF to XML,
            4) fills in the form-factor tables."""
        CIFdir='cif/'#folder with CIF files
        if not os.path.isdir(CIFdir):
            os.mkdir(CIFdir)
        XMLdir='xml/'#folder with XML files
        if not os.path.isdir(XMLdir):
            os.mkdir(XMLdir)
        FFdir='ff/'#folder with from-factor tables
        if not os.path.isdir(FFdir):
            os.mkdir(FFdir)
        cifpath=os.path.join(CIFdir,'%d.cif'%self.ID)
        if not os.path.isfile(cifpath):#checking if the file is already downloaded
            #downloading CIF file for the selected structure ID
            urllib.urlretrieve('http://www.crystallography.net/cod/%d.cif'%self.ID,cifpath)
        config=XaNSoNS.config()#creating new XML configuration
        ffpath=os.path.join(FFdir,'%d_FFtable_%s.txt'%(self.ID,self.source))
        config.Calculation.FFfilename=ffpath#path to form-factor table
        config.Calculation.scenario='Debye_hist'#using the histogram approximation
        config.Calculation.q.min=0.5#setting the range of values for scattering vector magnitude 
        config.Calculation.q.max=8.15
        config.Calculation.q.N=256#setting low resolution for x-ray form-factors (smooth functions)
        config.Calculation.source=self.source
        config.AddBlock()#adding new structural block
        config.Block[0].Atoms.MaxAtoms2XML=10000#all atoms will be stored in XML
        config.Block[0].Atoms.filename=cifpath#path to CIF file
        try:
            retcif=XaNSoNS.cif2xml(config,'')#importing from CIF file
            if retcif:
                return None            
            retff=XaNSoNS.formfactors(config,'')#filling in form-factor tables
            if retff:
                return None
        except:
            print('Error: unable to process structure with COD ID: %d'%self.ID)
            return None
        config.Calculation.q.N=4096#setting high resolution for diffraction pattern (sharp function)
        config.Calculation.name='%s_%s'%(self.ID,self.strsize)
        config.Block[0].CellVectors.N=self.size#setting the crystallite size (in unit cells)
        xmlpath=os.path.join(XMLdir,'%s_%s.xml'%(config.Calculation.name,self.source[:4]))
        config.ToXML(xmlpath)#saving XML configuration to file
        return xmlpath
    def plot(self,filename):
        """ Plots the simulated diffraction pattern
            filename : string
                Path to the file with the simulated powder diffraction pattern"""
        pattern=np.loadtxt(filename)
        from matplotlib import pyplot as plt
        fig=plt.figure(1)
        ax=fig.add_subplot(111)
        ax.plot(pattern[:,0],pattern[:,1],'-k')
        ax.set_title('COD ID: %d, %s diffraction pattern'%(self.ID,self.source))
        ax.text(0.96,0.96,self.strsize+' unit cells',transform=ax.transAxes,va='top',ha='right')
        ax.set_xlabel('q, A$^{-1}$')
        ax.set_ylabel('S, a.u.')
        ax.set_xlim(pattern[0,0],pattern[-1,0])
        plt.show()
    def run(self):
        """Runs the simulation and calls the plot() function"""
        xmlpath=self.set()
        if xmlpath is None:
            return None
        XaNSoNS.run(xmlpath,version=self.version,CIFcheck=False,FFcheck=False).wait()
        self.plot(os.path.basename(xmlpath).replace('.xml','_1D.txt'))
if  __name__ ==  "__main__" :
    from optparse import OptionParser
    parser = OptionParser()
    parser.add_option("-i", "--ID", type='int',dest="ID",help="COD ID")
    parser.add_option("-s", "--size", dest="size", type='string', default="10,10,10",
                      help="Size of the crystallite in unit cells \
                            (use coma as separator, default is '10,10,10')")
    parser.add_option("-n","--neutron", dest="neutron", action='store_true',default=False,
                      help="Switch source to 'neutron' (default is 'xray')")
    parser.add_option("-c","--cpu", dest="GPU", action='store_false',default=True,
                      help="Use CPU instead of GPU")
    parser.add_option("--CUDA", dest="CUDA", action='store_true',default=False,
                      help="Use CUDA version instead of OpenCL for GPU")
    (opt, args) = parser.parse_args()
    size=np.array([int(s) for s in opt.size.split(',')],dtype=int)
    if opt.neutron:
        source='neutron'
    else:
        source='xray'
    pcod=ProcessCOD(opt.ID,size,source,opt.GPU,opt.CUDA)
    pcod.run()
